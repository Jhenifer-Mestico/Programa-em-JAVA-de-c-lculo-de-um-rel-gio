/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package horas;

/**
 *
 * @author Jhenifer
 */
import javax.swing.JOptionPane;
public class Horas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int hr, min, minhrs;
        hr = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a hora: ", "Dado", JOptionPane.INFORMATION_MESSAGE));
        min = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o(s) minuto(s): ", "Dado", JOptionPane.INFORMATION_MESSAGE));
        minhrs = hr*60+min;
        JOptionPane.showMessageDialog(null, "Impressão: "+ minhrs + " minutos ", "Relogio", JOptionPane.INFORMATION_MESSAGE);
           
    }
    }
    

